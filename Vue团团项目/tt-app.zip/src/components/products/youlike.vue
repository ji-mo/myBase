<template>
    <div class="m-products-list" data-reactid="138">
      <h3 data-reactid="139">猜你喜欢</h3>
      <ul data-reactid="140">
        <li data-reactid="141" v-for="(item,index) in likeList" :key="index">
            <a href="/meishi/5460439/">
                <img
                  :src="item.image"
                />
                <p class="name">{{ item.name }}</p>
                <p class="desc">{{ item.desc }}</p>
                <p class="price">￥<span>{{ item.price }}</span></p>
            </a>
        </li>
      </ul>
    </div>
</template>
<script>
export default {
    data(){
        return {
            likeList:[{
                image: 'https://img.meituan.net//msmerchant/9036e931509f303c184fe5243ac05eb987341.jpg@188w_106h_1e_1c',
                name: '红荔村肠粉(1店云景店)',
                desc: '春风万佳/文锦渡',
                price: 19
            },{
                image: 'https://p0.meituan.net//merchantpic/6c7ce236366ce9a6c379c7b8bfd47b471310967.jpg@188w_106h_1e_1c',
                name: '奈瑞儿美颜SPA(宝安中心店)',
                desc: '宝安中心区',
                price: 199
            },{
                image: 'https://img.meituan.net//msmerchant/9036e931509f303c184fe5243ac05eb987341.jpg@188w_106h_1e_1c',
                name: '红荔村肠粉(1店云景店)',
                desc: '春风万佳/文锦渡',
                price: 19
            }]
        }
    }
};
</script>

<style lang="scss" >
    // @import '@/assets/css/products/like.scss'
</style>
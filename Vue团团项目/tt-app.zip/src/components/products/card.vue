<template>
  <div class="m-sum-card">
    <dt class="d-left">
      <h1 class="name">
        {{ $route.params.name }}
        <a href="#">
          <b></b>
          食品安全档案
        </a>
      </h1>
      <div class="el-rate">
        <el-rate
        v-model="$route.params.score"
        disabled
        show-score
        text-color="#666"
        score-template="{value}">
        </el-rate>
        <span>
            人均￥{{ $route.params.avgPrice }}
        </span>
      </div>
      <ul class="address">
        <li>
          地址：{{ $route.params.address }}
          <b></b>
        </li>
        <li>
          电话：
          0755-25024655
        </li>
        <li>
          营业时间：
          周一至周日 11:00-22:30
        </li>
      </ul>
      <ul class="tags clear">
        <li>
          <img src="https://p0.meituan.net/codeman/551290739062eda37e52999e2315f50c1887.png" />
          提供wifi
        </li>
      </ul>
    </dt>
    <dd>
      <div style="height: 100%; width: 100%;">
        <img
          src="https://img.meituan.net/msmerchant/b5c062e34abca4051c4992067c1471ee1082271.png@380w_214h_1e_1c"
        />
      </div>
      <ul>
        <li>
            <img
              src="https://img.meituan.net/msmerchant/6f7b49bcbc7754034fbc1d980de9125e6348681.png@92w_50h_1e_1c"
            />
        </li>
        <li>
            <img
              src="https://img.meituan.net/msmerchant/ad15d76e7645c1ede5fbf37ddfbeee2c5998572.png@92w_50h_1e_1c"
            />
        </li>
        <li>
            <img
              src="https://img.meituan.net/msmerchant/35bd43c908e106977c89ef00e4238b2613869101.png@92w_50h_1e_1c"
            />
        </li>
        <li>
            <img
              src="https://img.meituan.net/msmerchant/06429909c8758dc6d80edba33e39dd9e14187038.png@92w_50h_1e_1c"
            />
        </li>
      </ul>
    </dd>
    <div>
        <span></span>
    </div>
  </div>
</template>
<script>
export default {
}
</script>
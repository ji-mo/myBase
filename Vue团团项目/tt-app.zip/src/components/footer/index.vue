<template>
  <footer class="com-footer">
    <div class="footer-content">
      <div class="footer-link clearfix">
        <div class="footer-column">
          <dl>
            <dt>用户帮助</dt>
            <dd>
              <a rel="nofollow" href="http://www.meituan.com/help/selfservice" target="_blank">申请退款</a>
            </dd>
            <dd>
              <a
                rel="nofollow"
                href="http://www.meituan.com/help/selfservice?tab=2"
                target="_blank"
              >查看团团券密码</a>
            </dd>
            <dd>
              <a rel="nofollow" href="http://www.meituan.com/help/faq" target="_blank">常见问题</a>
            </dd>
            <dd>
              <a
                rel="nofollow"
                href="https://rules-center.meituan.com/rules-detail/4"
                target="_blank"
              >用户协议</a>
            </dd>
            <dd>
              <a
                rel="nofollow"
                href="https://rules-center.meituan.com/rules-detail/2"
                target="_blank"
              >隐私政策</a>
            </dd>
            <dd>
              <a rel="nofollow" href="http://www.meituan.com/about/anticheat" target="_blank">反诈骗公告</a>
            </dd>
            <dd>
              <a
                rel="nofollow"
                href="https://rules-center.meituan.com/customer-rights"
                target="_blank"
              >消费者权益保障</a>
            </dd>
          </dl>
          <dl>
            <dt>团团服务</dt>
            <dd>
              <a href="http://waimai.meituan.com/" target="_blank">团团外卖</a>
            </dd>
            <dd>
              <a href="http://hotel.meituan.com/" target="_blank">团团酒店</a>
            </dd>
            <dd>
              <a href="http://maoyan.com/" target="_blank">猫眼电影</a>
            </dd>
            <dd>
              <a href="https://peisong.meituan.com/" target="_blank">团团配送</a>
            </dd>
            <dd>
              <a href="https://www.mtyun.com/" target="_blank">团团云</a>
            </dd>
            <dd>
              <a href="http://www.dianping.com/" target="_blank">大众点评</a>
            </dd>
            <dd>
              <a href="https://minsu.meituan.com/" target="_blank">团团民宿</a>
            </dd>
            <dd>
              <a href="https://mad.meituan.com" target="_blank">无人配送</a>
            </dd>
          </dl>
        </div>
        <div class="footer-column">
          <dl>
            <dt>商家合作</dt>
            <dd>
              <a rel="nofollow" href="http://b.meituan.com/canyin/PC" target="_blank">团团餐饮商户中心</a>
            </dd>
            <dd>
              <a
                rel="nofollow"
                href="https://ecom.meituan.com/bizsettle/settle?utm_source=mt_C_my"
                target="_blank"
              >美食商家入驻(非外卖)</a>
            </dd>
            <dd>
              <a href="https://kd.meituan.com/" target="_blank">团团外卖开店申请</a>
            </dd>
            <dd>
              <a
                href="http://shouyin.meituan.com?utm_source=inner&amp;utm_medium=mtpc"
                target="_blank"
              >团团收银官网</a>
            </dd>
            <dd>
              <a
                rel="nofollow"
                href="http://page.peisong.meituan.com/apply/join"
                target="_blank"
              >外卖配送加盟申请</a>
            </dd>
            <dd>
              <a href="https://xue.meituan.com/?from=mtpc" target="_blank">团团点评餐饮学院</a>
            </dd>
            <dd>
              <a
                rel="nofollow"
                href="https://ruzhu.meituan.com/settle/hotel/propaganda.html"
                target="_blank"
              >酒店商家入驻</a>
            </dd>
            <dd>
              <a
                rel="nofollow"
                href="https://ruzhu.meituan.com/settle/trip/pc.html"
                target="_blank"
              >境内度假商家入驻</a>
            </dd>
            <dd>
              <a
                rel="nofollow"
                href="https://e.dianping.com/claimcpc/page/index?source=mt"
                target="_blank"
              >综合商家入驻</a>
            </dd>
            <dd>
              <a rel="nofollow" href="https://minsu.meituan.com/about/" target="_blank">团团民宿房东商家入驻</a>
            </dd>
            <dd>
              <a href="http://pc.meituan.com/?activity_code=mtpcdb" target="_blank">商家开票申请</a>
            </dd>
            <dd>
              <a
                rel="nofollow"
                href="https://h5.youzan.com/v2/feature/nALm22bkFF?dc_ps=2039811416638097413.200001"
                target="_blank"
              >团团点评智能收银机</a>
            </dd>
            <dd>
              <a
                rel="nofollow"
                href="https://developer.meituan.com/?from=mtpcsw"
                target="_blank"
              >团团点评餐饮开放平台</a>
            </dd>
            <dd>
              <a
                rel="nofollow"
                href="https://recommend-zc.meituan.com/opportunity?channel=1"
                target="_blank"
              >团团点评收单</a>
            </dd>
            <dd>
              <a
                rel="nofollow"
                href="https://paidui.meituan.com/?activity_code=167_00038050"
                target="_blank"
              >免费使用团团排队</a>
            </dd>
            <dd>
              <a
                rel="nofollow"
                href="https://i.meituan.com/awp/hfe/block/6c4bec785dce/11188/index.html"
                target="_blank"
              >快驴进货商家合作</a>
            </dd>
            <dd>
              <a rel="nofollow" href="https://shangou.meituan.com/joinin" target="_blank">团团闪购商家入驻</a>
            </dd>
          </dl>
        </div>
        <div class="footer-column">
          <dl>
            <dt>代理商加盟</dt>
            <dd>
              <a
                rel="nofollow"
                href="https://mfe.waimai.meituan.com/mfepro/client-h5/#/login"
                target="_blank"
              >团团外卖代理商招募</a>
            </dd>
            <dd>
              <a
                rel="nofollow"
                href="https://daili.meituan.com/?comeFrom=mtwebBusinesscoopd"
                target="_blank"
              >到店餐饮代理商招募</a>
            </dd>
            <dd>
              <a
                rel="nofollow"
                href="http://www.dianping.com/apollo/agent/index?source=mtpcd"
                target="_blank"
              >非餐饮代理商招募</a>
            </dd>
            <dd>
              <a rel="nofollow" href="http://union.meituan.com/" target="_blank">团团联盟</a>
            </dd>
            <dd>
              <a
                rel="nofollow"
                href="https://wenjuan.meituan.com/survey/4332711"
                target="_blank"
              >团团收银招募线上分销商</a>
            </dd>
            <dd>
              <a
                rel="nofollow"
                href="https://agent.meituan.com/zhaoshang?partnerSource=3"
                target="_blank"
              >团团点评5S服务商招募</a>
            </dd>
            <dd>
              <a
                rel="nofollow"
                href="https://zf.meituan.com?partnerSource=3"
                target="_blank"
              >团团收单渠道代理商招募</a>
            </dd>
          </dl>
          <dl>
            <dt>团团规则</dt>
            <dd>
              <a rel="nofollow" href="https://rules-center.meituan.com/" target="_blank">规则中心</a>
            </dd>
            <dd>
              <a rel="nofollow" href="https://rules-center.meituan.com/rules" target="_blank">规则目录</a>
            </dd>
            <dd>
              <a
                rel="nofollow"
                href="https://rules-center.meituan.com/advices"
                target="_blank"
              >规则评议院</a>
            </dd>
          </dl>
        </div>
        <div class="footer-column">
          <dl>
            <dt>关注团团</dt>
            <dd>
              <a rel="nofollow" href="http://weibo.com/meituan" target="_blank">团团新浪微博</a>
            </dd>
          </dl>
          <dl>
            <dt>公司信息</dt>
            <dd>
              <a rel="nofollow" href="https://about.meituan.com/" target="_blank">关于我们</a>
            </dd>
            <dd>
              <a rel="nofollow" href="https://about.meituan.com/investor.html" target="_blank">投资者关系</a>
            </dd>
            <dd>
              <a rel="nofollow" href="http://zhaopin.meituan.com/" target="_blank">加入我们</a>
            </dd>
            <dd>
              <a
                rel="nofollow"
                href="https://dpapp-appeal.meituan.com/#/shopCreditRegulationPC"
                target="_blank"
              >商户诚信公约及管理办法</a>
            </dd>
            <dd>
              <a
                rel="nofollow"
                href="https://i.meituan.com/awp/ffe/insurance-website/index.html#/"
                target="_blank"
              >保险经纪资质</a>
            </dd>
          </dl>
          <dl>
            <dt>廉正举报</dt>
            <dd>
              <a
                rel="nofollow"
                href="https://jubao.meituan.com/app/home?source=1"
                target="_self"
              >廉正举报平台</a>
            </dd>
          </dl>
          <dl>
            <dt>知识产权</dt>
            <dd>
              <a rel="nofollow" href="https://ipr.meituan.com?source=1" target="_blank">知识产权维权平台</a>
            </dd>
          </dl>
        </div>
        <div class="footer-column">
          <dl>
            <dt>消费者服务热线</dt>
            <dd>
              外卖消费者：
              <a rel="nofollow" href="tel:10109777" target="_blank">10109777</a>
            </dd>
            <dd>
              猫眼消费者：
              <a rel="nofollow" href="tel:10105335" target="_blank">10105335</a>
            </dd>
            <dd>
              其他消费者：
              <a rel="nofollow" href="tel:10107888" target="_blank">10107888</a>
            </dd>
          </dl>
          <dl>
            <dt>商家服务热线</dt>
            <dd>
              外卖&amp;餐饮商家：
              <a rel="nofollow" href="tel:10105557" target="_blank">10105557</a>
            </dd>
            <dd>
              休闲娱乐、丽人、ktv、教育、结婚、亲子、家装等商家：
              <a rel="nofollow" href="tel:10100107" target="_blank">10100107</a>
            </dd>
          </dl>
          <dl>
            <dt>投诉举报专区</dt>
            <dd>
              违法和不良信息举报电话：
              <a rel="nofollow" href="tel:4006018900" target="_blank">4006018900</a>
            </dd>
            <dd>
              举报邮箱：
              <a
                rel="nofollow"
                href="mailto:tousujubao@meituan.com"
                target="_self"
              >tousujubao@meituan.com</a>
            </dd>
            <dd>
              <a rel="nofollow" href="https://www.12377.cn/" target="_blank">网上有害信息举报</a>
            </dd>
          </dl>
          <dl>
            <dt>
              <a
                rel="nofollow"
                href="https://ecom.meituan.com/bizsettle/settle/merchantsSettle"
                target="_blank"
              >商家自助入驻团团入口</a>
            </dt>
          </dl>
          <dl>
            <dt>
              <a rel="nofollow" href="https://isp.meituan.com/signup" target="_blank">供应商注册入口</a>
            </dt>
          </dl>
        </div>
      </div>
      <div class="footer-copyright clearfix">
        <div class="footer-copyright-left">
          <p>©团团网团购 meituan.com
            <a
              href="http://www.beianbeian.com/beianxinxi/283f39a9-4c00-427a-97ef-3c7a9e1e0af1.html"
            >京ICP证070791号</a>
            <a href="http://www.miitbeian.gov.cn/">京ICP备10211739号</a>
            <a href="https://www.meituan.com/about/rules" target="_blank">电子公告服务规则</a>
          </p>
          <p>
            <a
              href="https://i.meituan.com/brunch/default/right"
              target="_blank"
            >广播电视节目制作经营许可证（京）字第03889号</a>
          </p>
        </div>
        <div class="footer-copyright-right">
          <a
            href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=11010502025545"
            target="_blank"
          >京公网安备11010502025545号</a>
          <div class="footer-copyright-cert">
            <a
              class="sp-ft sp-ft--record"
              href="https://www.meituan.com/about/openinfo"
              title="备案信息"
              target="_blank"
            >备案信息</a>
            <a
              class="sp-ft sp-ft--knet"
              href="http://t.knet.cn/index_new.jsp"
              title="可信网站认证"
              target="_blank"
            >可信网站</a>
            <a
              class="sp-ft sp-ft--12315"
              href="http://www.bj315.org/xfwq/lstd/201209/t20120910_3344.shtml?dnrpluojqxbceiqq"
              title="12315消费争议"
              target="_blank"
            >12315消费争议</a>
          </div>
        </div>
      </div>
    </div>
  </footer>
</template>
<script>
export default {};
</script>
<style lang="scss">
@import "@/assets/css/public/footer.scss";
</style>

<template>
    <div class="page-detail">
        <el-row class="m-crumbs">
            <crumbs />
        </el-row>
        <el-row>
            <card />
        </el-row>
    </div>
</template>
<script>
import crumbs from '@/components/products/crumbs.vue'
import card from '@/components/products/card.vue'
export default {
    components: {
        crumbs,
        card
    }
}
</script>
<style lang="scss">
    @import '@/assets/css/detail/index.scss'
</style>